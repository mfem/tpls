#if !defined(_CHARACTERISTIC_DA_)
#define _CHARACTERISTIC_DA_

#include <petsc/private/characteristicimpl.h>        /*I "petsccharacteristic.h" I*/

typedef struct {
  PetscInt dummy;
} Characteristic_DA;

#endif /* _CHARACTERISTIC_DA_ */
