#include <occa/lang/expr.hpp>
#include <occa/lang/parser.hpp>
#include <occa/lang/statement.hpp>
#include <occa/lang/variable.hpp>
#include <occa/lang/builtins/attributes/barrier.hpp>

namespace occa {
  namespace lang {
    namespace attributes {
      barrier::barrier() {}

      std::string barrier::name() const {
        return "barrier";
      }

      bool barrier::forStatement(const int sType) const {
        return (sType & statementType::empty);
      }

      bool barrier::isValid(const attributeToken_t &attr) const {
        if (attr.kwargs.size()) {
          attr.printError("[@barrier] does not take kwargs");
          return false;
        }
        const int argCount = (int) attr.args.size();
        if (argCount > 1) {
          attr.printError("[@barrier] takes at most one argument");
          return false;
        }
        if ((argCount == 1) &&
            (!attr.args[0].expr ||
             attr.args[0].expr->type() != exprNodeType::string)) {
          attr.printError("[@barrier] must have no arguments"
                          " or have one string argument");
          return false;
        }
        return true;
      }
    }
  }
}
