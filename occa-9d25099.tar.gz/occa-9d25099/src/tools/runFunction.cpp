
// -------------[ DO NOT EDIT ]-------------
//  THIS IS AN AUTOMATICALLY GENERATED FILE
//  EDIT: scripts/setup_kernel_operators.py
// =========================================

switch (argc) {
  case 0:
    f();
    break;
  case 1:
    f(args[0]);
    break;
  case 2:
    f(args[0], args[1]);
    break;
  case 3:
    f(args[0], args[1], args[2]);
    break;
  case 4:
    f(args[0], args[1], args[2], args[3]);
    break;
  case 5:
    f(args[0], args[1], args[2], args[3], args[4]);
    break;
  case 6:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5]);
    break;
  case 7:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6]);
    break;
  case 8:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7]);
    break;
  case 9:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8]);
    break;
  case 10:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9]);
    break;
  case 11:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10]);
    break;
  case 12:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11]);
    break;
  case 13:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12]);
    break;
  case 14:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13]);
    break;
  case 15:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14]);
    break;
  case 16:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15]);
    break;
  case 17:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16]);
    break;
  case 18:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17]);
    break;
  case 19:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18]);
    break;
  case 20:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19]);
    break;
  case 21:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20]);
    break;
  case 22:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21]);
    break;
  case 23:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22]);
    break;
  case 24:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23]);
    break;
  case 25:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24]);
    break;
  case 26:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25]);
    break;
  case 27:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26]);
    break;
  case 28:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27]);
    break;
  case 29:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28]);
    break;
  case 30:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29]);
    break;
  case 31:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30]);
    break;
  case 32:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31]);
    break;
  case 33:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32]);
    break;
  case 34:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33]);
    break;
  case 35:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34]);
    break;
  case 36:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35]);
    break;
  case 37:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35], args[36]);
    break;
  case 38:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35], args[36], args[37]);
    break;
  case 39:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35], args[36], args[37], args[38]);
    break;
  case 40:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35], args[36], args[37], args[38], args[39]);
    break;
  case 41:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35], args[36], args[37], args[38], args[39],
      args[40]);
    break;
  case 42:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35], args[36], args[37], args[38], args[39],
      args[40], args[41]);
    break;
  case 43:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35], args[36], args[37], args[38], args[39],
      args[40], args[41], args[42]);
    break;
  case 44:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35], args[36], args[37], args[38], args[39],
      args[40], args[41], args[42], args[43]);
    break;
  case 45:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35], args[36], args[37], args[38], args[39],
      args[40], args[41], args[42], args[43], args[44]);
    break;
  case 46:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35], args[36], args[37], args[38], args[39],
      args[40], args[41], args[42], args[43], args[44],
      args[45]);
    break;
  case 47:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35], args[36], args[37], args[38], args[39],
      args[40], args[41], args[42], args[43], args[44],
      args[45], args[46]);
    break;
  case 48:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35], args[36], args[37], args[38], args[39],
      args[40], args[41], args[42], args[43], args[44],
      args[45], args[46], args[47]);
    break;
  case 49:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35], args[36], args[37], args[38], args[39],
      args[40], args[41], args[42], args[43], args[44],
      args[45], args[46], args[47], args[48]);
    break;
  case 50:
    f(args[0], args[1], args[2], args[3], args[4],
      args[5], args[6], args[7], args[8], args[9],
      args[10], args[11], args[12], args[13], args[14],
      args[15], args[16], args[17], args[18], args[19],
      args[20], args[21], args[22], args[23], args[24],
      args[25], args[26], args[27], args[28], args[29],
      args[30], args[31], args[32], args[33], args[34],
      args[35], args[36], args[37], args[38], args[39],
      args[40], args[41], args[42], args[43], args[44],
      args[45], args[46], args[47], args[48], args[49]);
    break;
}

