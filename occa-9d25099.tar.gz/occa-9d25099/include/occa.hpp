#ifndef OCCA_HEADER
#define OCCA_HEADER

#include <occa/array.hpp>
#include <occa/core.hpp>
#include <occa/dtype.hpp>
#include <occa/io.hpp>
#include <occa/modes.hpp>
#include <occa/tools.hpp>
#include <occa/types.hpp>

#endif
