#include <occa/defines.hpp>

#if OCCA_CUDA_ENABLED
#  ifndef OCCA_MODES_CUDA_HEADER
#  define OCCA_MODES_CUDA_HEADER

#include <occa/modes/cuda/utils.hpp>

#  endif
#endif
