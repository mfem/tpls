#ifndef OCCA_LANG_TYPE_POINTER_HEADER
#define OCCA_LANG_TYPE_POINTER_HEADER

#include <occa/lang/type/type.hpp>

namespace occa {
  namespace lang {
    class pointer_t {
    public:
      qualifiers_t qualifiers;

      pointer_t();
      pointer_t(const qualifiers_t &qualifiers_);
      pointer_t(const pointer_t &other);

      bool has(const qualifier_t &qualifier) const;

      void operator += (const qualifier_t &qualifier);
      void operator -= (const qualifier_t &qualifier);
      void operator += (const qualifiers_t &others);

      void add(const fileOrigin &origin,
               const qualifier_t &qualifier);

      void add(const qualifierWithSource &qualifier);
    };

    io::output& operator << (io::output &out,
                             const pointer_t &pointer);

    printer& operator << (printer &pout,
                          const pointer_t &pointer);
  }
}

#endif
