#ifndef OCCA_DTYPE_HEADER
#define OCCA_DTYPE_HEADER

#include <occa/dtype/dtype.hpp>
#include <occa/dtype/builtins.hpp>

#endif
