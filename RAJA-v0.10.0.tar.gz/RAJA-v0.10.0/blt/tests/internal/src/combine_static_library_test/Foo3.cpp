// Copyright (c) 2017-2019, Lawrence Livermore National Security, LLC and
// other BLT Project Developers. See the top-level COPYRIGHT file for details
//
// SPDX-License-Identifier: (BSD-3-Clause)

#include "Foo3.hpp"

namespace blt_test
{

Foo3::Foo3()
{
  // TODO Auto-generated constructor stub

}

Foo3::~Foo3()
{
  // TODO Auto-generated destructor stub
}

std::string Foo3::output()
{
  return "I am Foo #3";
}
} /* namespace blt_test */
