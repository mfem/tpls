// Copyright (c) 2017-2019, Lawrence Livermore National Security, LLC and
// other BLT Project Developers. See the top-level COPYRIGHT file for details
//
// SPDX-License-Identifier: (BSD-3-Clause)

#include <iostream>
#include "Foo1.hpp"

namespace blt_test
{

Foo1::Foo1()
{
  // TODO Auto-generated constructor stub

}

Foo1::~Foo1()
{
  // TODO Auto-generated destructor stub
}

std::string Foo1::output()
{
  return "I am Foo #1";
}

} /* namespace blt_test */
