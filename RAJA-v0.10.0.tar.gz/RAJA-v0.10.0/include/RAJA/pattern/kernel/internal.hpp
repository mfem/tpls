/*!
 ******************************************************************************
 *
 * \file
 *
 * \brief   Header file for loop kernel internals.
 *
 ******************************************************************************
 */

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
// Copyright (c) 2016-19, Lawrence Livermore National Security, LLC
// and RAJA project contributors. See the RAJA/COPYRIGHT file for details.
//
// SPDX-License-Identifier: (BSD-3-Clause)
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

#ifndef RAJA_pattern_kernel_internal_HPP
#define RAJA_pattern_kernel_internal_HPP

#include "RAJA/config.hpp"

#include "RAJA/index/IndexSet.hpp"
#include "RAJA/internal/LegacyCompatibility.hpp"
#include "RAJA/util/macros.hpp"
#include "RAJA/util/types.hpp"

#include "camp/camp.hpp"
#include "camp/concepts.hpp"
#include "camp/tuple.hpp"

#include "RAJA/pattern/detail/privatizer.hpp"
#include "RAJA/pattern/kernel/ArgHelper.hpp"

#include <iterator>
#include <type_traits>

namespace RAJA
{
namespace internal
{


template <typename... Stmts>
using StatementList = camp::list<Stmts...>;


template <typename ExecPolicy, typename... EnclosedStmts>
struct Statement {
  Statement() = delete;

  using enclosed_statements_t = StatementList<EnclosedStmts...>;
  using execution_policy_t = ExecPolicy;
};


template <typename T>
using remove_all_t =
    typename std::remove_cv<typename std::remove_reference<T>::type>::type;

// Universal base of all For wrappers for type traits
struct ForList {
};
struct ForBase {
};
struct CollapseBase {
};
template <camp::idx_t ArgumentId, typename Policy>
struct ForTraitBase : public ForBase {
  constexpr static camp::idx_t index_val = ArgumentId;
  using index = camp::num<ArgumentId>;
  using index_type = camp::nil;  // default to invalid type
  using policy_type = Policy;
  using type = ForTraitBase;  // make camp::value compatible
};

template <typename Iterator>
struct iterable_difftype_getter {
  using type = typename std::iterator_traits<
      typename Iterator::iterator>::difference_type;
};

template <typename Segments>
using difftype_list_from_segments =
    typename camp::transform<iterable_difftype_getter, Segments>::type;


template <typename Segments>
using difftype_tuple_from_segments =
    typename camp::apply_l<camp::lambda<camp::tuple>,
                           difftype_list_from_segments<Segments>>::type;


template <typename Iterator>
struct iterable_value_type_getter {
  using type =
      typename std::iterator_traits<typename Iterator::iterator>::value_type;
};

template <typename Segments>
using value_type_list_from_segments =
    typename camp::transform<iterable_value_type_getter, Segments>::type;


template <typename Segments>
using index_tuple_from_segments =
    typename camp::apply_l<camp::lambda<camp::tuple>,
                           value_type_list_from_segments<Segments>>::type;


template <typename Policy>
struct StatementExecutor {
};


template <typename PolicyType,
          typename SegmentTuple,
          typename ParamTuple,
          typename... Bodies>
struct LoopData {

  using Self = LoopData<PolicyType, SegmentTuple, ParamTuple, Bodies...>;

  using offset_tuple_t =
      difftype_tuple_from_segments<typename SegmentTuple::TList>;

  using index_tuple_t = index_tuple_from_segments<typename SegmentTuple::TList>;

  using policy_t = PolicyType;


  using segment_tuple_t = SegmentTuple;
  SegmentTuple segment_tuple;

  using param_tuple_t = ParamTuple;
  ParamTuple param_tuple;

  using BodiesTuple = camp::tuple<Bodies...>;
  const BodiesTuple bodies;
  offset_tuple_t offset_tuple;

  RAJA_INLINE
  LoopData(SegmentTuple const &s, ParamTuple const &p, Bodies const &... b)
      : segment_tuple(s), param_tuple(p), bodies(b...)
  {
    assign_begin_all();
  }

  template <typename PolicyType0,
            typename SegmentTuple0,
            typename ParamTuple0,
            typename... Bodies0>
  RAJA_INLINE RAJA_HOST_DEVICE constexpr LoopData(
      LoopData<PolicyType0, SegmentTuple0, ParamTuple0, Bodies0...> &c)
      : segment_tuple(c.segment_tuple),
        param_tuple(c.param_tuple),
        bodies(c.bodies),
        offset_tuple(c.offset_tuple)
  {
  }

  template <camp::idx_t Idx, typename IndexT>
  RAJA_HOST_DEVICE RAJA_INLINE void assign_offset(IndexT const &i)
  {
    camp::get<Idx>(offset_tuple) = i;
  }

  template <typename ParamId, typename IndexT>
  RAJA_HOST_DEVICE RAJA_INLINE void assign_param(IndexT const &i)
  {
    using param_t = camp::at_v<typename param_tuple_t::TList, ParamId::param_idx>;
    camp::get<ParamId::param_idx>(param_tuple) = param_t(i);
  }

  template <typename ParamId>
  RAJA_HOST_DEVICE RAJA_INLINE
  auto get_param() ->
    camp::at_v<typename param_tuple_t::TList, ParamId::param_idx>
  {
    return camp::get<ParamId::param_idx>(param_tuple);
  }

  template <camp::idx_t Idx>
  RAJA_HOST_DEVICE RAJA_INLINE int assign_begin()
  {
    camp::get<Idx>(offset_tuple) = 0;
    return 0;
  }

  template <camp::idx_t... Idx>
  RAJA_HOST_DEVICE RAJA_INLINE void assign_begin_all_expanded(
      camp::idx_seq<Idx...> const &)
  {
    VarOps::ignore_args(assign_begin<Idx>()...);
  }

  RAJA_HOST_DEVICE
  RAJA_INLINE
  void assign_begin_all()
  {
    assign_begin_all_expanded(
        camp::make_idx_seq_t<camp::tuple_size<offset_tuple_t>::value>{});
  }


  template <camp::idx_t... Idx>
  RAJA_HOST_DEVICE RAJA_INLINE index_tuple_t
  get_begin_index_tuple_expanded(camp::idx_seq<Idx...> const &) const
  {
    return camp::make_tuple((*camp::get<Idx>(segment_tuple).begin())...);
  }

  RAJA_HOST_DEVICE
  RAJA_INLINE
  index_tuple_t get_begin_index_tuple() const
  {
    return get_begin_index_tuple_expanded(
        camp::make_idx_seq_t<camp::tuple_size<offset_tuple_t>::value>{});
  }


  template <camp::idx_t... Idx>
  RAJA_HOST_DEVICE RAJA_INLINE index_tuple_t
  get_minimum_index_tuple_expanded(camp::idx_seq<Idx...> const &) const
  {
    return camp::make_tuple(
        ((*camp::get<Idx>(segment_tuple).begin() <=
          *camp::get<Idx>(segment_tuple).end())
             ? *camp::get<Idx>(segment_tuple).begin()
             : *(camp::get<Idx>(segment_tuple).end() - 1))...);
  }

  RAJA_HOST_DEVICE
  RAJA_INLINE
  index_tuple_t get_minimum_index_tuple() const
  {
    return get_minimum_index_tuple_expanded(
        camp::make_idx_seq_t<camp::tuple_size<offset_tuple_t>::value>{});
  }
};


RAJA_SUPPRESS_HD_WARN
template <camp::idx_t LoopIndex,
          camp::idx_t... OffsetIdx,
          camp::idx_t... ParamIdx,
          typename Data>
RAJA_HOST_DEVICE RAJA_INLINE void invoke_lambda_expanded(
    camp::idx_seq<OffsetIdx...> const &,
    camp::idx_seq<ParamIdx...> const &,
    Data &&data)
{
  camp::get<LoopIndex>(data.bodies)
    ((camp::get<OffsetIdx>(data.segment_tuple).begin()[camp::get<OffsetIdx>(data.offset_tuple)])...,
     camp::get<ParamIdx>(data.param_tuple)...);
}


template <camp::idx_t LoopIndex, typename Data>
RAJA_INLINE RAJA_HOST_DEVICE void invoke_lambda(Data &&data)
{
  using Data_t = camp::decay<Data>;
  using offset_tuple_t = typename Data_t::offset_tuple_t;
  using param_tuple_t = typename Data_t::param_tuple_t;

  invoke_lambda_expanded<LoopIndex>(
      camp::make_idx_seq_t<camp::tuple_size<offset_tuple_t>::value>{},
      camp::make_idx_seq_t<camp::tuple_size<param_tuple_t>::value>{},
      std::forward<Data>(data));
}

RAJA_SUPPRESS_HD_WARN
template<camp::idx_t LoopIndex, typename Data, typename... targLists>
RAJA_INLINE RAJA_HOST_DEVICE void invoke_custom_lambda(Data &&data,
                                                       camp::list<targLists...> const &)
{
  camp::get<LoopIndex>(data.bodies)(extractor<targLists>::extract_arg(data)...);
}

//Helper to launch lambda with custom arguments
template <camp::idx_t LoopIndex, typename targList, typename Data>
RAJA_INLINE RAJA_HOST_DEVICE void invoke_lambda_with_args(Data &&data)
{

  invoke_custom_lambda<LoopIndex>(data,targList{});
                                     
}

template <camp::idx_t ArgumentId, typename Data>
RAJA_INLINE RAJA_HOST_DEVICE auto segment_length(Data const &data) ->
    typename std::iterator_traits<
        typename camp::at_v<typename Data::segment_tuple_t::TList,
                            ArgumentId>::iterator>::difference_type
{
  return camp::get<ArgumentId>(data.segment_tuple).end() -
         camp::get<ArgumentId>(data.segment_tuple).begin();
}


template <camp::idx_t idx, camp::idx_t N, typename StmtList>
struct StatementListExecutor;


template <camp::idx_t statement_index,
          camp::idx_t num_statements,
          typename StmtList>
struct StatementListExecutor {

  template <typename Data>
  static RAJA_INLINE void exec(Data &&data)
  {

    // Get the statement we're going to execute
    using statement = camp::at_v<StmtList, statement_index>;

    // Execute this statement
    StatementExecutor<statement>::exec(std::forward<Data>(data));

    // call our next statement
    StatementListExecutor<statement_index + 1, num_statements, StmtList>::exec(
        std::forward<Data>(data));
  }
};


/*
 * termination case, a NOP.
 */

template <camp::idx_t num_statements, typename StmtList>
struct StatementListExecutor<num_statements, num_statements, StmtList> {

  template <typename Data>
  static RAJA_INLINE void exec(Data &&)
  {
  }
};


template <typename StmtList, typename Data>
RAJA_INLINE void execute_statement_list(Data &&data)
{
  StatementListExecutor<0, camp::size<StmtList>::value, StmtList>::exec(
      std::forward<Data>(data));
}

template <typename Data, typename... EnclosedStmts>
struct GenericWrapper : GenericWrapperBase {
  using data_t = camp::decay<Data>;

  data_t &data;

  RAJA_INLINE
  constexpr explicit GenericWrapper(data_t &d) : data{d} {}

  RAJA_INLINE
  void exec() { execute_statement_list<camp::list<EnclosedStmts...>>(data); }
};


/*!
 * Convenience object used to create thread-private a LoopData object.
 */
template <typename T>
struct NestedPrivatizer {
  using data_t = typename T::data_t;
  using value_type = camp::decay<T>;
  using reference_type = value_type &;

  data_t privatized_data;
  value_type privatized_wrapper;

  RAJA_INLINE
  constexpr NestedPrivatizer(const T &o)
      : privatized_data{o.data}, privatized_wrapper(privatized_data)
  {
  }

  RAJA_INLINE
  reference_type get_priv() { return privatized_wrapper; }
};


}  // end namespace internal
}  // end namespace RAJA


#endif /* RAJA_pattern_kernel_internal_HPP */
