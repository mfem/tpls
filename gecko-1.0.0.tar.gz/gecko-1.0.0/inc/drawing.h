#ifndef DRAWING_H
#define DRAWING_H

#include "graph.h"
#include "device.h"

namespace Gecko {

class Graph;

// 2D graph drawing
class Drawing {
public:
  Drawing(Device* d) : device(d) {}
  void draw(const Graph* g);
private:
  Device* device;
};

}

#endif
