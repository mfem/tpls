#ifndef OPTIONS_H
#define OPTIONS_H

#include <cfloat>
#include <limits>

#define GECKO_PART_FRAC 4    // ratio of max to min weight for aggregation
#define GECKO_CR_SWEEPS 1    // number of compatible relaxation sweeps
#define GECKO_GS_SWEEPS 1    // number of Gauss-Seidel relaxation sweeps
#define GECKO_ADJLIST 0      // use adjacency list (1) or matrix (0)
#define GECKO_NONRECURSIVE 0 // use nonrecursive permutation algorithm
#define GECKO_WINDOW_MAX 16  // max number of nodes in subgraph

#define FLOAT_EPSILON std::numeric_limits<Float>::epsilon()
#define FLOAT_MAX std::numeric_limits<Float>::max()

namespace Gecko {

  typedef unsigned int uint;

// precision for node positions and computations
#ifdef GECKO_DOUBLE_PRECISION
  typedef double Float;
#else
  typedef float Float;
#endif
}

#endif
