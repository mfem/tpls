#ifndef DEVICE_H
#define DEVICE_H

#include "options.h"

namespace Gecko {

// drawing device abstract base class
class Device {
public:
  virtual ~Device() {}
  virtual void begin() {}
  virtual void end() {}
  virtual void node(Float x, Float r, Float gray = 0.5) = 0;
  virtual void edge(Float xi, Float xj, Float weight) = 0;
  virtual void edge(Float xi, Float xj, Float weight, bool top) = 0;
};

}

#endif
