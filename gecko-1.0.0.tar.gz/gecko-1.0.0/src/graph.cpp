#include <algorithm>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include "heap.h"
#include "graph.h"
#include "subgraph.h"

using namespace std;
using namespace Gecko;

// Constructor.
Graph::Graph(uint level) : level(level)
{
  node.push_back(Node(-1, 0, 1, Node::null));
  adj.push_back(Node::null);
  weight.push_back(0);
  bond.push_back(0);
}

// Insert node.
Node::Index
Graph::insert(Float length)
{
  Node::Index p = node.size();
  perm.push_back(p);
  node.push_back(Node(-1, length));
  return p;
}

// Insert arc (i, j).
Arc::Index
Graph::insert(Node::Index i, Node::Index j, Float w, Float b)
{
  for (Node::Index k = i - 1; node[k].arc == Arc::null; k--)
    node[k].arc = adj.size();
  adj.push_back(j);
  weight.push_back(w);
  bond.push_back(b);
  node[i].arc = adj.size();
  return adj.size() - 1;
}

// Remove edge {i, j}.
void
Graph::remove(Node::Index i, Node::Index j)
{
  // Remove (i, j).
  Arc::Index a = find(i, j);
  adj.erase(adj.begin() + a);
  weight.erase(weight.begin() + a);
  bond.erase(bond.begin() + a);
  for (Node::Index k = i; k < node.size(); k++)
    node[k].arc--;
  // Remove (j, i).
  Arc::Index b = find(j, i);
  adj.erase(adj.begin() + b);
  weight.erase(weight.begin() + b);
  bond.erase(bond.begin() + b);
  for (Node::Index k = j; k < node.size(); k++)
    node[k].arc--;
}

// Find arc (i, j).
Arc::Index
Graph::find(Node::Index i, Node::Index j) const
{
  for (Arc::Index a = begin(i); a < end(i); a++)
    if (adj[a] == j)
      return a;
  return Arc::null;
}

// Return source node i in arc a = (i, j).
Node::Index
Graph::source(Arc::Index a) const
{
  Node::Index j = adj[a];
  for (Arc::Index b = begin(j); b < end(j); b++) {
    Node::Index i = adj[b];
    if (begin(i) <= a && a < end(i))
      return i;
  }
  // should never get here
  throw std::runtime_error("internal data structure corrupted");
}

// Return reverse arc (j, i) of arc a = (i, j).
Arc::Index
Graph::reverse(Arc::Index a) const
{
  Node::Index j = adj[a];
  for (Arc::Index b = begin(j); b < end(j); b++) {
    Node::Index i = adj[b];
    if (begin(i) <= a && a < end(i))
      return b;
  }
  return Arc::null;
}

// Find first directed arc if one exists.
bool
Graph::directed(Node::Index* ip, Node::Index* jp) const
{
  for (Node::Index j = 1; j < node.size(); j++)
    for (Arc::Index a = begin(j); a < end(j); a++) {
      Node::Index i = adj[a];
      if (!find(i, j)) {
        if (ip)
          *ip = i;
        if (jp)
          *jp = j;
        return true;
      }
    }
  return false;
}

// Add contribution of fine arc to coarse graph.
void
Graph::update(Node::Index i, Node::Index j, Float w, Float b)
{
  Arc::Index a = find(i, j);
  if (a == Arc::null)
    insert(i, j, w, b);
  else {
    weight[a] += w;
    bond[a] += b;
  }
}

// Transfer contribution of fine arc a to coarse node p.
void
Graph::transfer(Graph* g, const vector<Float>& part, Node::Index p, Arc::Index a, Float f) const
{
  Float w = f * weight[a];
  Float m = f * bond[a];
  Node::Index j = target(a);
  Node::Index q = node[j].parent;
  if (q == Node::null) {
    for (Arc::Index b = begin(j); b < end(j); b++)
      if (part[b] > 0) {
        q = node[adj[b]].parent;
        if (q != p)
          g->update(p, q, w * part[b], m * part[b]);
      }
  }
  else
    g->update(p, q, w, m);
}

// Compute cost of a subset of arcs incident on node placed at pos.
WeightedSum
Graph::cost(const vector<Arc::Index>& subset, Float pos) const
{
  WeightedSum c;
  for (Arc::ConstPtr ap = subset.begin(); ap != subset.end(); ap++) {
    Arc::Index a = *ap;
    Node::Index j = target(a);
    Float l = fabs(node[j].pos - pos);
    Float w = weight[a];
    functional->accumulate(c, WeightedValue(l, w));
  }
  return c;
}

// Compute cost of graph layout.
Float
Graph::cost() const
{
  WeightedSum c;
  Node::Index i = 1;
  for (Arc::Index a = 1; a < adj.size(); a++) {
    while (end(i) <= a)
      i++;
    Node::Index j = target(a);
    Float l = length(i, j);
    Float w = weight[a];
    functional->accumulate(c, WeightedValue(l, w));
  }
  return functional->mean(c);
}

// Swap the two nodes in positions k and l, k <= l.
void
Graph::swap(uint k, uint l)
{
  Node::Index i = perm[k];
  perm[k] = perm[l];
  perm[l] = i;
  Float p = node[i].pos - node[i].hlen;
  do {
    i = perm[k];
    p += node[i].hlen;
    node[i].pos = p;
    p += node[i].hlen;
  } while (k++ != l);
}

// Optimize continuous position of a single node.
Float
Graph::optimal(Node::Index i) const
{
  vector<WeightedValue> v;
  for (Arc::Index a = begin(i); a < end(i); a++) {
    Node::Index j = adj[a];
    if (placed(j))
      v.push_back(WeightedValue(node[j].pos, weight[a]));
  }
  return v.empty() ? -1 : functional->optimum(v);
}

// Compute coarse graph with roughly half the number of nodes.
Graph*
Graph::coarsen()
{
  progress->beginphase(this, string("coarse"));
  Graph* g = new Graph(level - 1);
  g->functional = functional;
  g->progress = progress;

  // Compute importance of nodes in fine graph.
  DynamicHeap<Node::Index, Float> heap;
  for (Node::Index i = 1; i < node.size(); i++) {
    node[i].parent = Node::null;
    Float w = 0;
    for (Arc::Index a = begin(i); a < end(i); a++)
      w += bond[a];
    heap.insert(i, w);
  }

  // Select set of important nodes from fine graph that will remain in
  // coarse graph.
  vector<Node::Index> child(1, Node::null);
  while (!heap.empty()) {
    Node::Index i;
    Float w = 0;
    heap.extract(i, w);
    if (w < 0)
      break;
    child.push_back(i);
    node[i].parent = g->insert(2 * node[i].hlen);

    // Reduce importance of neighbors.
    for (Arc::Index a = begin(i); a < end(i); a++) {
      Node::Index j = adj[a];
      if (heap.find(j, w))
        heap.update(j, w - 2 * bond[a]);
    }
  }

  // Assign parts of remaining nodes to aggregates.
  vector<Float> part = bond;
  for (Node::Index i = 1; i < node.size(); i++)
    if (!persistent(i)) {
      // Find all connections to coarse nodes.
      Float w = 0;
      Float max = 0;
      for (Arc::Index a = begin(i); a < end(i); a++) {
        Node::Index j = adj[a];
        if (persistent(j)) {
          w += part[a];
          if (max < part[a])
            max = part[a];
        }
        else
          part[a] = -1;
      }
      max /= GECKO_PART_FRAC;

      // Weed out insignificant connections.
      for (Arc::Index a = begin(i); a < end(i); a++)
        if (0 < part[a] && part[a] < max) {
          w -= part[a];
          part[a] = -1;
        }

      // Compute node fractions (interpolation matrix) and assign
      // partial nodes to aggregates.
      for (Arc::Index a = begin(i); a < end(i); a++)
        if (part[a] > 0) {
          part[a] /= w;
          Node::Index p = node[adj[a]].parent;
          g->node[p].hlen += part[a] * node[i].hlen;
        }
    }

  // Transfer arcs to coarse graph.
  for (Node::Index p = 1; p < g->node.size(); p++) {
    Node::Index i = child[p];
    for (Arc::Index a = begin(i); a < end(i); a++) {
      transfer(g, part, p, a);
      Node::Index j = adj[a];
      if (!persistent(j)) {
        Arc::Index b = find(j, i);
        if (part[b] > 0)
          for (Arc::Index c = begin(j); c < end(j); c++) {
            Node::Index k = adj[c];
            if (k != i)
              transfer(g, part, p, c, part[b]);
          }
      }
    }
  }

#if DEBUG
  if (g->directed())
    throw runtime_error("directed edge found");
#endif

  // Free memory.
  vector<Float> t = bond;
  bond.swap(t);

  progress->endphase(this, false);

  return g;
}

// Order nodes according to coarsened graph layout.
void
Graph::refine(const Graph* graph)
{
  progress->beginphase(this, string("refine"));

  // Place persistent nodes.
  DynamicHeap<Node::Index, Float> heap;
  for (Node::Index i = 1; i < node.size(); i++)
    if (persistent(i)) {
      Node::Index p = node[i].parent;
      node[i].pos = graph->node[p].pos;
    }
    else {
      node[i].pos = -1;
      Float w = 0;
      for (Arc::Index a = begin(i); a < end(i); a++) {
        Node::Index j = adj[a];
        if (persistent(j))
          w += weight[a];
      }
      heap.insert(i, w);
    }

  // Place remaining nodes in order of decreasing connectivity with
  // already placed nodes.
  while (!heap.empty()) {
    Node::Index i = 0;
    heap.extract(i);
    node[i].pos = optimal(i);
    for (Arc::Index a = begin(i); a < end(i); a++) {
      Node::Index j = adj[a];
      Float w;
      if (heap.find(j, w))
        heap.update(j, w + weight[a]);
    }
  }

  place(true);
  progress->endphase(this, true);
}

// Perform m sweeps of compatible or Gauss-Seidel relaxation.
void
Graph::relax(bool compatible, uint m)
{
  progress->beginphase(this, compatible ? string("crelax") : string("frelax"));
  while (m--)
    for (uint k = 0; k < perm.size() && !progress->quit(); k++) {
      Node::Index i = perm[k];
      if (!compatible || !persistent(i))
        node[i].pos = optimal(i);
    }
  place(true);
  progress->endphase(this, true);
}

// Optimize successive n-node subgraphs.
void
Graph::optimize(uint n)
{
  if (n > perm.size())
    n = perm.size();
  ostringstream count;
  count << setw(2) << n;
  progress->beginphase(this, string("perm") + count.str());
  Subgraph* subgraph = new Subgraph(this, n);
  for (uint k = 0; k <= perm.size() - n && !progress->quit(); k++)
    subgraph->optimize(k);
  delete subgraph;
  progress->endphase(this, true);
}

// Place all nodes according to their positions.
void
Graph::place(bool sort)
{
  place(sort, 0, perm.size());
}

// Place nodes {k, ..., k + n - 1} according to their positions.
void
Graph::place(bool sort, uint k, uint n)
{
  // Place nodes.
  if (sort)
    stable_sort(perm.begin() + k, perm.begin() + k + n, Node::Comparator(node.begin()));

  // Assign node positions according to permutation.
  for (Float p = k ? node[perm[k - 1]].pos + node[perm[k - 1]].hlen : 0; n--; k++) {
    Node::Index i = perm[k];
    p += node[i].hlen;
    node[i].pos = p;
    p += node[i].hlen;
  }
}

// Perform one V-cycle.
void
Graph::vcycle(uint n, uint work)
{
  if (n < nodes() && nodes() < edges() && level && !progress->quit()) {
    Graph* graph = coarsen();
    graph->vcycle(n, work + edges());
    refine(graph);
    delete graph;
  }
  else
    place();
  if (edges()) {
    relax(true, GECKO_CR_SWEEPS);
    relax(false, GECKO_GS_SWEEPS);
    for (uint w = edges(); w * (n + 1) < work; w *= ++n);
    n = std::min(n, uint(GECKO_WINDOW_MAX));
    if (n)
      optimize(n);
  }
}

// Generate a random permutation of the nodes.
void
Graph::shuffle(uint seed)
{
  srand(seed);
  for (uint k = 0; k < perm.size(); k++) {
    uint l = (k + rand()) % nodes();
    std::swap(perm[k], perm[l]);
  }
  place();
}

// Recompute bonds for k'th V-cycle.
void
Graph::reweight(uint k)
{
  bond.resize(weight.size());
  for (Arc::Index a = 1; a < adj.size(); a++)
    bond[a] = functional->bond(weight[a], length(a), k);
}

// Linearly order graph.
void
Graph::order(Functional* functional, uint iterations, uint window, uint period, uint seed, Progress* progress)
{
  // Initialize graph.
  this->functional = functional;
  this->progress = progress ? progress : new Progress;
  if (period == 0)
    period--;
  for (level = 0; (1u << level) < nodes(); level++);
  place();
  Float mincost = cost();
  vector<Node::Index> minperm = perm;
  if (seed)
    shuffle(seed);

  // Perform specified number of V-cycles.
  this->progress->beginorder(this, mincost);
  for (uint k = 1; k <= iterations && !this->progress->quit(); window += k % period ? 0 : 1, k++) {
    this->progress->beginiter(this, k, iterations, window);
    reweight(k);
    vcycle(window);
    Float c = cost();
    if (c < mincost) { 
      mincost = c;
      minperm = perm;
    }
    this->progress->enditer(this, mincost, c);
  }
  perm = minperm;
  place();
  this->progress->endorder(this, mincost);

  if (!progress)
    delete this->progress;
}
