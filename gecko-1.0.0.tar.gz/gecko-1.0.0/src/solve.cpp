void
Graph::descend(uint n)
{
  phase("grelax");
  for (uint k = 0; k < n; k++) {
    vector<Float> g(node.size());
    Float s = 0;
    for (Node::Index i = 1; i < node.size(); i++) {
      g[i] = 0;
      for (Arc::Index a = begin(i); a < end(i); a++) {
        Node::Index j = adj[a];
        Float w = weight[a];
        Float r = node[i].hlen + node[j].hlen;
        Float d = node[j].pos - node[i].pos;
        Float e = (1 + d * d / r * r) / 2;
        g[i] += ((e * e * e - 1) / (e * e * e * d * d + e * r * r)) * d * w;
      }
      s += g[i] * g[i];
    }
    Float delta = 1.0 / nodes();
    for (Node::Index i = 1; i < node.size(); i++)
      node[i].pos += delta * g[i];
    if (sqrt(s / nodes()) < 1e-3)
      break;
  }
  drawing->draw(this);
  place(true);
  drawing->draw(this);
  phase(true);
}

#include "Eigen/Core"
//#include "Eigen/LU"
//#include "Eigen/SVD"
USING_PART_OF_NAMESPACE_EIGEN

// conjugate gradient solver
static void
cgsolve(const MatrixXd& a, const VectorXd& b, VectorXd& x)
{
  Gecko::uint n = b.size();
  VectorXd r = a * x - b;
  VectorXd p = VectorXd::Zero(n);
  for (Gecko::uint i = 0; i < n; i++) {
    double s = r.squaredNorm();
    if (s <= 0)
      break;
    p -= r / s;
    VectorXd q = a * p;
    double t = p.dot(q);
    x += p / t;
    r += q / t;
  }
}

// solve linearized problem
void
Graph::solve(uint k, uint n)
{
  MatrixXd a = MatrixXd::Zero(n + 2, n + 2);
  VectorXd b = VectorXd::Zero(n + 2);
  for (uint l = 0; l < n; l++) {
    Node::Index i = perm[k + l];
    for (Arc::Index e = begin(i); e < end(i); e++) {
      Node::Index j = adj[e];
      Float r = node[j].pos - node[i].pos;
      Float w = weight[e] / (r * r);
      a(l, l) += w;
      uint m;
      for (m = 0; m < n && perm[k + m] != j; m++);
      if (m != n)
        a(l, m) -= w;
      b[l] += w * r;
    }
    a(l, n + 0) = a(n + 0, l) = 2 * node[i].hlen;
    a(l, n + 1) = a(n + 1, l) = 2 * node[i].hlen * node[i].pos;
  }
  VectorXd x = VectorXd::Zero(n + 2);
//  if (!a.lu().solve(b, &x))
//    throw std::runtime_error("LU solver failed");
//  if (!a.svd().solve(b, &x))
//    throw std::runtime_error("SVD solver failed");
  cgsolve(a, b, x);
  for (uint l = 0; l < n; l++) {
    Node::Index i = perm[k + l];
    node[i].pos += x[l];
  }
  place(true, k, n);
}

// approximately optimize over contiguous n-node windows
void
Graph::solve(uint n)
{
  if (n > perm.size())
    n = perm.size();
  ostringstream count;
  count << n;
  phase(string("solv") + count.str());
  for (uint k = 0; k <= perm.size() - n && !exit(); k++)
    solve(k, n);
  phase(true);
}
