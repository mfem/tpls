/*
** order version 1.0.1, Jan 12, 2010
** Part of the LOCAL Toolkit, UCRL-CODE-232243
** Written by Peter Lindstrom, Lawrence Livermore National Laboratory
**
**
**                                NOTICE
**
** This work was produced at the Lawrence Livermore National Laboratory
** (LLNL) under contract no. DE-AC-52-07NA27344 (Contract 44) between
** the U.S. Department of Energy (DOE) and Lawrence Livermore National
** Security, LLC (LLNS) for the operation of LLNL.  The rights of the
** Federal Government are reserved under Contract 44.
**
**
**                              DISCLAIMER
**
** This work was prepared as an account of work sponsored by an agency of
** the United States government.  Neither the United States government nor
** Lawrence Livermore National Security, LLC, nor any of their employees
** makes any warranty, expressed or implied, or assumes any legal liability
** or responsibility for the accuracy, completeness, or usefulness of any
** information, apparatus, product, or process disclosed, or represents
** that its use would not infringe privately owned rights.  Reference
** herein to any specific commercial product, process, or service by trade
** name, trademark, manufacturer, or otherwise does not necessarily
** constitute or imply its endorsement, recommendation, or favoring by the
** United States government or Lawrence Livermore National Security, LLC.
** The views and opinions of authors expressed herein do not necessarily
** state or reflect those of the United States government or Lawrence
** Livermore National Security, LLC, and shall not be used for advertising
** or product endorsement purposes.
**
**
**                            COMMERCIAL USE
**
** Commercialization of this product is prohibited without notifying the
** Department of Energy (DOE) or Lawrence Livermore National Security.
*/

#include <csignal>
#include <cstdio>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include "graph.h"
#include "drawing.h"
#include "postscript.h"

using namespace Gecko;
using namespace std;

//@p-r-i-v-a-t-e---t-y-p-e-s---------------------------------------------------

// progress reporting
class MyProgress : public Progress {
public:
  MyProgress(Drawing* d = 0) : drawing(d) {}
  void beginorder(const Graph* graph, Float cost) const
  {
    cerr << "f = " << fixed << setprecision(6) << cost << " { " << now();
  }
  void endorder(const Graph* graph, Float cost) const
  {
    cerr << "f = " << fixed << setprecision(6) << cost << " } " << now();
    if (drawing)
      drawing->draw(graph);
  }
  void beginiter(const Graph* graph, unsigned int iter, unsigned int maxiter, unsigned int window) const
  {
    cerr << "i = " << setw(width(maxiter)) << iter << "/" << maxiter << "  n = " << window << "  ";
  }
  void enditer(const Graph* graph, Float mincost, Float cost) const
  {
    cerr << "f = " << fixed << setprecision(6) << cost << "/" << mincost << "  " << now();
  }
  void beginphase(const Graph* graph, string name) const
  {
#if VERBOSE
    cerr << name << " V=" << setw(6) << graph->nodes() << " E=" << setw(6) << graph->edges();
#endif
  }
  void endphase(const Graph* graph, bool show) const
  {
#if VERBOSE
    if (show)
      cerr << " f=" << fixed << setw(12) << setprecision(6) << graph->cost();
    cerr << endl;
#endif
    if (drawing && show)
      drawing->draw(graph);
  }
  bool quit() const { return _exit; }
  static void exit() { _exit = true; }
private:
  static volatile bool _exit;
  Drawing* drawing;

  // current time
  string now() const
  {
    time_t t = time(0);
    return string(ctime(&t));
  }

  // number of digits in m
  int width(unsigned int m) const
  {
    int w = 1;
    while (m >= 10) {
      m /= 10;
      w++;
    }
    return w;
  }
};

volatile bool MyProgress::_exit = false;

// derived graph class with specialized reader and progress reports
class ChacoGraph : public Graph {
public:
  // constructor
  ChacoGraph() : Graph() {}

  // read chaco graph from file
  bool read(FILE* file);
};

// read graph from file in chaco format
bool
ChacoGraph::read(FILE* file)
{
  try {
    char line[0x10000];
    if (!fgets(line, sizeof(line), file))
      throw string("file is empty");

    // determine number of nodes, edges, and type of graph
    unsigned int nv, ne, fmt;
    bool weighted = false;
    switch (sscanf(line, "%u%u%u", &nv, &ne, &fmt)) {
      case 2:
        break;
      case 3:
        switch (fmt) {
          case 0:
            break;
          case 1:
            weighted = true;
            break;
          default:
            throw string("invalid graph format specifier");
        }
        break;
      default:
        throw string("invalid first line in graph file");
    }

    // read nodes and their neighbors
    for (Node::Index i = 1; i <= nv; i++) {
      if (insert() != i) {
        ostringstream ss;
        ss << i;
        throw string("cannot insert node" + ss.str());
      }
      if (!fgets(line, sizeof(line), file)) {
        ostringstream ss;
        ss << i;
        throw string("no data for node" + ss.str());
      }
      int n;
      for (unsigned int k = 0, j; sscanf(line + k, "%u%n", &j, &n) == 1; k += n) {
        double w = 1;
        if (weighted) {
          k += n;
          if (sscanf(line + k, "%lf%n", &w, &n) != 1) {
            ostringstream ss;
            ss << i;
            throw string("cannot read weight for node" + ss.str());
          }
        }
        insert(i, j, Float(w), Float(w));
      }
    }

    // make sure graph is undirected
    Node::Index i, j;
    if (directed(&i, &j)) {
      ostringstream ss;
      ss << i << ", " << j;
      throw string("no arc (") + ss.str() + string("): graph is directed");
    }
  }
  catch (string message) {
    cerr << "ERROR: " << message << endl;
    return false;
  }

  return true;
}

//@p-r-i-v-a-t-e---f-u-n-c-t-i-o-n-s-------------------------------------------

// signal handler for catching CTRL-C
static void
handler(int sig)
{
  MyProgress::exit();
  signal(sig, SIG_DFL);
}

//@m-a-i-n---f-u-n-c-t-i-o-n---------------------------------------------------

int
main(int argc, char *argv[])
{
  Functional* functional = 0;               // ordering functional
  unsigned int iterations = 1;              // number of V cycles
  unsigned int window = 2;                  // initial window size
  unsigned int period = 1;                  // iterations between window increment
  unsigned int seed = (unsigned)time(NULL); // random number seed
  FILE* psfile = 0;                         // PostScript file

  // parse command-line arguments
  try {
    switch (argc) {
      case 7:
        if (!(psfile = fopen(argv[6], "w")))
          throw std::string("cannot create PostScript file");
        /*FALLTHROUGH*/
      case 6:
        if (sscanf(argv[5], "%u", &seed) != 1)
          throw std::string("invalid seed");
        /*FALLTHROUGH*/
      case 5:
        if (sscanf(argv[4], "%u", &period) != 1)
          throw std::string("invalid period");
        /*FALLTHROUGH*/
      case 4:
        if (sscanf(argv[3], "%u", &window) != 1)
          throw std::string("invalid window");
        /*FALLTHROUGH*/
      case 3:
        if (sscanf(argv[2], "%u", &iterations) != 1)
          throw std::string("invalid number of iterations");
        /*FALLTHROUGH*/
      case 2:
        if (argv[1][1])
          throw std::string("invalid functional");
        switch (*argv[1]) {
          case 'h':
            functional = new FunctionalHarmonic();
            break;
          case 'g':
            functional = new FunctionalGeometric();
            break;
          case 's':
            functional = new FunctionalSMR();
            break;
          case 'a':
            functional = new FunctionalArithmetic();
            break;
          case 'r':
            functional = new FunctionalRMS();
            break;
          case 'm':
            functional = new FunctionalMaximum();
            break;
          default:
            throw std::string("invalid functional");
        }
        break;
      default:
        throw std::string("invalid number of arguments");
    }
  }
  catch (std::string message) {
    cerr << "ERROR: " << message << endl;
    cerr << "Usage: order <functional> [iterations [window [period [seed [psfile]]]]] <graph >permutation" << endl;
    cerr << "Functionals:" << endl;
    cerr << "  h: harmonic mean" << endl;
    cerr << "  g: geometric mean" << endl;
    cerr << "  s: square mean root" << endl;
    cerr << "  a: arithmetic mean (1-sum, mla)" << endl;
    cerr << "  r: root mean square (2-sum)" << endl;
    cerr << "  m: maximum (bandwidth)" << endl;
    return EXIT_FAILURE;
  }

  // set up signal handler to catch interrupts
  signal(SIGHUP, handler);
  signal(SIGINT, handler);
  signal(SIGTERM, handler);

  // read graph
  ChacoGraph graph;
  if (!graph.read(stdin))
    return EXIT_FAILURE;

  // optionally create PostScript drawing
  PostScript* ps = psfile ? new PostScript(graph.nodes(), psfile) : 0;
  Drawing* drawing = ps ? new Drawing(ps) : 0;
  MyProgress* progress = new MyProgress(drawing);

  // order graph
  fprintf(stderr, "s = %u\n", seed);
  graph.order(functional, iterations, window, period, seed, progress);
  delete functional;

  // close PostScript file
  if (drawing) {
    delete drawing;
    delete ps;
    fclose(psfile);
  }
  delete progress;

  // output position of each node in reordered graph
  for (Node::Index i = 1; i <= graph.nodes(); i++)
    cout << graph.rank(i) << endl;

  return EXIT_SUCCESS;
}
